<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.example.model.Employee" %>
<%
    // If this page was hit directly (not via the servlet), redirect so the list gets loaded
    if (request.getAttribute("employees") == null) {
        response.sendRedirect("employee?action=list");
        return;
    }
    List<Employee> employees = (List<Employee>) request.getAttribute("employees");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f6fa; }
        h1 { color: #2c3e50; }
        table { border-collapse: collapse; width: 100%; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #2c3e50; color: #fff; }
        tr:hover { background: #f1f1f1; }
        a.btn { text-decoration: none; padding: 5px 10px; border-radius: 4px; font-size: 13px; margin-right: 5px; }
        a.edit { background: #3498db; color: #fff; }
        a.delete { background: #e74c3c; color: #fff; }
        a.add { display: inline-block; margin-bottom: 15px; background: #27ae60; color: #fff;
                padding: 8px 14px; border-radius: 4px; text-decoration: none; }
        .empty { padding: 20px; text-align: center; color: #888; }
    </style>
</head>
<body>
    <h1>Employee Details</h1>
    <a class="add" href="employee?action=new">+ Add New Employee</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Salary</th>
            <th>Actions</th>
        </tr>
        <% if (employees.isEmpty()) { %>
        <tr>
            <td colspan="6" class="empty">No employees yet. Click "Add New Employee" to create one.</td>
        </tr>
        <% } %>
        <% for (Employee emp : employees) { %>
        <tr>
            <td><%= emp.getId() %></td>
            <td><%= emp.getName() %></td>
            <td><%= emp.getEmail() %></td>
            <td><%= emp.getDepartment() %></td>
            <td><%= emp.getSalary() %></td>
            <td>
                <a class="btn edit" href="employee?action=edit&id=<%= emp.getId() %>">Edit</a>
                <a class="btn delete" href="employee?action=delete&id=<%= emp.getId() %>"
                   onclick="return confirm('Delete this employee?');">Delete</a>
            </td>
        </tr>
        <% } %>
    </table>
</body>
</html>
