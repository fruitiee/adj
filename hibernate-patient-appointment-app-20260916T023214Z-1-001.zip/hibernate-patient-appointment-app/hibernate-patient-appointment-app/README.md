# Hibernate Patient Appointment App

A simple Java web app (Servlet + JSP + Hibernate + H2) for managing patient
appointments, with **Add**, **Edit**, and **Delete** on a single list page.

Uses the **H2 embedded database** — a plain Java library, not a separate
server you have to install. Data is stored in a local file
(`./data/appointment_db.mv.db`), created automatically the first time you
run the app.

## Project structure

```
hibernate-patient-appointment-app/
├── pom.xml
└── src/main/
    ├── java/com/example/
    │   ├── model/Appointment.java        # Hibernate entity
    │   ├── util/HibernateUtil.java       # SessionFactory singleton
    │   ├── dao/AppointmentDAO.java       # CRUD methods
    │   └── servlet/AppointmentServlet.java   # list / add / edit / update / delete routes
    ├── resources/hibernate.cfg.xml       # DB connection + Hibernate settings
    └── webapp/
        ├── index.jsp                     # appointment list, with Edit/Delete links
        ├── addAppointment.jsp            # new appointment form
        ├── editAppointment.jsp           # edit form
        └── WEB-INF/web.xml
```

## Fields

Each appointment has: Patient Name, Doctor Name, Appointment Date,
Appointment Time, Reason for Visit, and Status (Scheduled / Completed /
Cancelled). The list page shows a colored badge for status and is sorted by
date and time, soonest first.

## Prerequisites

- JDK 11+
- Apache Maven
- A servlet container such as Apache Tomcat 9 or 10

No database install required — H2 ships as a Maven dependency and runs
embedded inside the app.

## Run it (command line)

```bash
mvn clean package
```

Copy the resulting `target/hibernate-patient-appointment-app.war` into
`<TOMCAT_HOME>/webapps/`, start Tomcat, then open:

```
http://localhost:8080/hibernate-patient-appointment-app/
```

## Run it (Eclipse)

Same as before: import as an Existing Maven Project, make sure a Tomcat
server runtime is registered, add the project to the server, and hit Start
(or right-click the project → Run As → Run on Server).

## How it works

- `AppointmentServlet` is mapped to `/appointment` and handles everything
  through an `action` parameter:
  - `GET appointment?action=list` → shows all appointments (`index.jsp`)
  - `GET appointment?action=new` → shows the new-appointment form
  - `POST appointment?action=insert` → saves a new appointment
  - `GET appointment?action=edit&id=X` → shows the edit form pre-filled for appointment X
  - `POST appointment?action=update` → saves changes to an appointment
  - `GET appointment?action=delete&id=X` → deletes appointment X (with a JS confirm prompt)

- `AppointmentDAO` wraps all the Hibernate `Session`/`Transaction` code.

- `hibernate.hbm2ddl.auto=update` means the `appointment` table is created
  and kept in sync with `Appointment.java` automatically.

## Extending it

- Add a date-range filter or a "today's appointments" view on `index.jsp`.
- Prevent double-booking by checking for an existing appointment with the
  same doctor, date, and time before inserting.
- Add a patient ID / lookup instead of free-typing the patient name each
  time, once you're ready to link appointments to a separate Patient table.
